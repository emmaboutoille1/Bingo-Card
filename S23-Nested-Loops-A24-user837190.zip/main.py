"""
Name: Emma Boutoille
Date: September 28
Assignment 2.4 Bingo Card
"""
# You are on your own for this one.  Make sure that your code is efficient and as simple as possible. This will be the primary criteria for evaluation.

# ---------------- Imports --------------------
# New section to import libraries that help us code
import turtle # import turtle library
import time # import time library

# ------------------- Window Setup ----------------
# New section to setup our screen for graphics
wn = turtle.Screen() # create window called wn
wn.setup(height=600, width=800) # set window size
wn.title("S2.4 Nested For Loops") # Window title
wn.bgcolor("light blue") # set background colour to light blue

# -------------------  Turtle Setup -------------------------
# Create turtles
tia = turtle.Turtle() # create turtle
tia.width(1) # set tia's width to 1
tia.shape("circle") # set tia's shape to a circle
tia.turtlesize(1) # set tia's size to 1
tia.speed(4) # set tia's speed to 4

penstyle_title = ("Roboto Slab", 50, "bold") # set the text font, size, and style to Roboto Slab size 50 bold
penstyle_numbers = ("Arial", 20) # set the text font and size to Arial size 20
penstyle_rules = ("Arial", 15) # set the text font and size to Arial size 15

# -------------   Functions -------------
def draw_squareSCXY(sq_size, draw_color, new_x, new_y): # create a function with 3 parameters sq_size, draw_color, turn_angle
  tia.pu() # pen up
  tia.goto(new_x, new_y) # move to new coordinates using parameters
  tia.pd() # pen down
  tia.color(draw_color) # set color to parameter
  for i in range(4): # repeat the loop 4 times
    tia.fd(sq_size) # draw 1 side using sq_size
    tia.rt(90) # turn 90

def draw_border(): # create a function to draw the border
  tia.pu() # lift pen up
  tia.goto(-315, 215) # move tia to -315, 255
  for a in [25]: # set the loop to repeat 25 times
    for k in range(4): # set the loop to repeat 4 times
      for j in ["red", "OrangeRed2", "orange", "gold", "yellow", "light green","green", "dark green", "sky blue", "cyan", "dark blue", "purple", "pink", "hot pink", "magenta", "white", "black"]: # create a list to list all the colours in the border
        tia.color(j) # set tia's color to j
        tia.stamp() # leave a copy of tia behind
        tia.fd(a) # move tia forward by a units
      tia.rt(90) # rotate tia to the right by 90 degrees
    
def draw_grid(): # create a function to draw the grid
  x_pos = -300 # set starting x value
  for i in [200, 120, 40, -40, -120]: # set y values for squares
    tia.pu() # pen up
    tia.goto(-300,i) # move tia to -300 for the x value and i for y
    tia.width(2) # set tia's width to 2
    tia.pd() # pen down
    for j in ["red", "purple", "green", "blue", "orange"]: # colours for square
      draw_squareSCXY(80, j, x_pos, i) # change color and x value
      x_pos+= 80 # decrease the y position by 80
    x_pos = -300 # reset the y position to 300

def write_title(): # create a function to write the title
  x_pos = -290 # set starting x value
  y_pos = 220 # set starting y value
  lst_letters = ["B", "I", "N", "G", "O"] # create a list that lists the letters for the title
  lst_colors = ["red", "purple", "green", "blue", "orange"] # create a list that lists the colors for the letters in the title
  for i in range(5): # set the loop to repeat 5 times
    tia.pu() # pen up
    tia.goto(x_pos, y_pos) # goto x,y values
    tia.pd() # pen down
    tia.color(lst_colors[i]) # set color to list element
    tia.write(lst_letters[i], font = penstyle_title) # set word to list element
    x_pos+=80 # increase x value by 80
   
def write_numbers(): # create a function to write the numbers
  x_value = -280 # starting x
  y_value = 150 # starting y
  lst_lists = [["14", "3", "6", "8", "9"], ["26", "21", "16", "22", "29"], ["37", "39", " ", "38", "42"], ["53", "57", "48", "54", "50"], ["63", "74", "72", "70", "69"]] #create lists that list the numbers inside a list
  lst_colors = ["red", "purple", "green", "blue", "orange"] # create a list that lists the colors for the numbers
  for i in range(5): # number of lists
    for j in range(5): # number of elements in each list
      tia.pu() # pen up
      tia.goto(x_value, y_value) # move tia to x,y values
      tia.color(lst_colors[i]) # set color to list element
      tia.write(lst_lists[i][j], font = penstyle_numbers) # set word to list element
      y_value-=82 # decrease the y value 82
    y_value = 150 # reset y value to 150
    x_value +=82 # increase x value by 82
    
def draw_star(): # create a function to draw the star in the free space
  tia.pu() # pen up
  tia.goto(-135,7) # move tia to -135,7
  tia.pd() # pen down
  for i in ["yellow"]: #list of colors
    tia.color(i) # set tia's color to i
    tia.fillcolor(i) # tell tia to fill shape in the color i
    tia.begin_fill() # tia begins to fill shape
    for j in range(5): # set loop to repeat 5 times
      tia.fd(70) # move tia forward 70
      tia.rt(144) # rotate tia to the right by 144 degrees
    tia.end_fill() # tell tia to stop filling shape

def mark_bingo(): # create a function to mark a bingo
  time.sleep(1) # wait one second
  x_pos = -260 # starting x
  y_pos = 160 # starting y
  lst_colors = ["red", "purple", "green", "blue", "orange"] # lists the colors for the bingo marks
  for i in lst_colors: # set loop to repeat for each element in the list
    tia.pu() # pen up
    tia.shapesize(3) # set tia's shape size to 3
    tia.color(i) # set color to list element
    tia.goto(x_pos, y_pos) # goto x,y values
    tia.pd() # pen down
    tia.stamp() # leave a copy of tia behind
    x_pos+=80 # increase the x value by 80

# -------------------------Main Program ------------------
# Create title
write_title() # call on function write_title

# Draw the border
draw_border()

# Draw the grid
draw_grid() # call on function draw_grid

#Write the numbers
write_numbers() # call on function write_numbers

# Draw the star in the free space
draw_star() # call on function draw_star

# Mark a Bingo
mark_bingo()


